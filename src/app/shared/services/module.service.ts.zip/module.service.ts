/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable quote-props */
/* eslint-disable @typescript-eslint/quotes */
import { HttpBackend, HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Params, Router } from '@angular/router';
import { from, Observable, ReplaySubject, Subject } from 'rxjs';
import { retry } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { HTTP } from '@ionic-native/http/ngx';
import { AuthenticationService } from './authentication.service';
import { ConnectivityService } from './offline-code/connectivity.service';
import { ToastService } from './toast.service';
@Injectable({
  providedIn: 'root'
})
export class ModuleService {
  // eslint-disable-next-line @typescript-eslint/ban-types
  languageEvent: Subject<object> = new Subject<object>();
  isPagereload: Subject<object> = new Subject<object>();
  // eslint-disable-next-line @typescript-eslint/ban-types
  mapEvent: Subject<object> = new Subject<object>();
  reloadEvent = new ReplaySubject();
  private httpClient: HttpClient;
  constructor(private http: HttpClient, httpBackend: HttpBackend, private httpobj: HTTP, private auth: AuthenticationService,
    private routerServices: Router, private connectivity: ConnectivityService,public toastService: ToastService
  ) {
    this.httpClient = new HttpClient(httpBackend);
    const body: any = {
      "user_id": localStorage.getItem('user_id'),
      "language": localStorage.getItem("language"),
    };
    if (body) {
      this.setProperty(body);
    }
  }

  setProperty(property: any) {
    this.reloadEvent.next(property);
  }
  onReLoadEvent() {
    return this.reloadEvent;
  }

  getVoilationType(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/voliationTypeList');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/voliationTypeList', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {

          if (res.status == 401) {
            this.logout();
          }

          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  // getVoilationType() {
  //   return this.http.get(environment.vmsApiUrl + 'getSideTypes');
  // }

  getVoilationTitle(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/voliationTitleList/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/voliationTitleList/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  getSideCode(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/sideCode');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/sideCode', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  getSideCodeWiseData(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/sideCodeWiseData/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/sideCodeWiseData/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  getPlateSource(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/plateSourceList');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/plateSourceList', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  
  getPlateCode(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/plateCodeList');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/plateCodeList', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  getOldCode(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/oldCode');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/oldCode', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  getDocumentType(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/documentType');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/documentType', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  getViolationCategory(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/violationCategory/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/violationCategory/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  ListViolationCategories(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/ListviolationCategories');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/ListviolationCategories', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  // getViolationCategory(id: any) {
  //   return this.http.get(environment.vmsApiUrl + '/getSideTypeCategories/' + id);
  // }

  getFineCode(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/fineCode/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/fineCode/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  ListFineCodes(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/ListfineCategoryCode');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/ListfineCategoryCode', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  // getFineCode(id: any) {
  //   return this.http.get(environment.vmsApiUrl + 'getFineCodes/' + id);
  // }
  getFineAmount(id: any): Observable<any> {

    //return this.http.get(environment.apiUrl + '/getFineamount/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/getFineamount/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  getReservedCode(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/reservedCode/');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/reservedCode/', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  // getReservedCode() {
  //   return this.http.get(environment.vmsApiUrl + 'getReservedCodes/');
  // }
  getArea(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/getArea');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/getArea', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  getViolationList(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/voilations/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/voilations/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  getvoilationSearchByField(documentNumber): Observable<any> {
    // return this.http.get(environment.apiUrl + '/voilationSearchByField/' + documentNumber)
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/voilationSearchByField/' + documentNumber, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  // voilationSearchByPlateNo: (documentNumber, callback) => {
  //

  voilationSearchByPlateNo(documentNumber): Observable<any> {
    //return this.http.get(environment.apiUrl + '/voilationSearchByPlateNo/' + documentNumber)
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/voilationSearchByPlateNo/' + documentNumber, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  getPlateSourceID(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/plateSourceId/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/plateSourceId/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  setAddVoliationTitle(body: any): Observable<any> {
    //  return this.http.post(environment.apiUrl + '/addVoliationTitle/', body,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/addVoliationTitle/', body, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  violationCreation(body: any): Observable<any> {
    // return this.http.post(environment.apiUrl + '/addValidation/', body,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/addValidation/', body, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  createWarning(body: any): Observable <any>{
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      //let nativeHttpCall = this.httpobj.post('https://rakdedlicdstg.ega.lan/QSInternalTest/QZone/IntegrationServices/RAKDED_LicenseDetailsByParam', body, {});
      // this.httpobj.setDataSerializer('urlencoded');
      // this.httpobj.setHeader('*', 'Content-Type', 'application/x-www-form-urlencoded');
      console.log("craetawarning body", body);
      
      let nativeHttpCall = this.httpobj.post(environment.warningApiUrl +'insertWarning', body, {});
      //let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/GetLicenseParamInfo/', body, {});
      from(nativeHttpCall).subscribe(
        
        (res: any) => {
          console.log("subresp",res)
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.ResponseContent
            ? JSON.parse(res.data.ResponseContent)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          console.log("subErr",err)
          this.toastService.showError(JSON.stringify(err),"Alert");
          alert(JSON.stringify(err))
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
     });
    
  }

  viewViolationDeatails(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/viewViolations/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/viewViolations/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }


  viewAmendDeatails(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/amendViolationList/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/amendViolationList/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  insertAmendViolatinRequest(data: any): Observable<any> {
    //return this.http.post(environment.apiUrl + '/amendViolation', data,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/amendViolation', data, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  editViolationData(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/editViolation/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/editViolation/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  updateViolationData(id: any, data: any): Observable<any> {
    // return this.http.post(environment.apiUrl + '/updateViolationIdWise/' + id, data,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/updateViolationIdWise/' + id, data, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  cancelviolation(id: any, data: any): Observable<any> {
    //return this.http.post(environment.apiUrl + '/cancelviolation/' + id, data,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/cancelviolation/' + id, data, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  amendRequestList(id: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/amendReqestList/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.apiUrl + '/amendReqestList/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  getVdcamImgDelete(id: any): Observable<any> {
    //return this.http.delete(environment.apiUrl + '/deleteImage/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.delete(environment.apiUrl + '/deleteImage/' + id, {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  searchSideCode(id: any, data: any): Observable<any> {
    //return this.http.post(environment.apiUrl + '/searchSideCode', data,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/searchSideCode', data, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }
  //Web Api Publish button
  publishViolation(data: any): Observable<any> {
    //return this.http.post(environment.vmsApiUrl + 'publishViolation', data,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.vmsApiUrl + 'publishViolation', data, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          this.toastService.showError(err,"Alert")
          Observer.error(err);
          Observer.complete();
        }
      ),
      (error) => {
        this.toastService.showError(error,"Alert")
      };;
    });
  }

  //app.post('/getViolationexitsinoneyear',vmsController.getViolationexitsinoneyear)

  getViolationexitsinoneyear(data: any): Observable<any> {
    //return this.http.post(environment.apiUrl + '/getViolationexitsinoneyear', data,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/getViolationexitsinoneyear', data, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  getViolationexistsin3days(data: any): Observable<any> {
    //return this.http.post(environment.apiUrl + '/validate3daysviolation', data,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/validate3daysviolation', data, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  /* Start  Sync Offline Violation, Violation Documents & Violation videos */


  violationCreationOffline(body: any): Observable<any> {
    //return this.http.post(environment.apiUrl + '/addViolationOffline/', body,{});
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/addViolationOffline/', body, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  /* End Sync Offline Violation, Violation Documents & Violation videos */

  sendsms(data: any) {
    let sms_host_url: any = environment.sms_host_url;
    let sms_port: any = environment.sms_port;
    let sms_api_source: any = environment.sms_api_source;
    let sms_api_username: any = environment.sms_api_username;
    let sms_api_password: any = environment.sms_api_password;
    let sms_api_msgtype: any = environment.sms_api_msgtype;
    let sms_api_dlr = environment.sms_api_dlr;

    let petitionLink = environment.vmsApiUrl + "/petitions/" + data.reference_number;
    let paymentLink = environment.vmsApiUrl + "/violations/preview/" + data.reference_number;
    let modile_number = "971522952656"
    let smsmessage = " A violation has been filed against you for committing a violation punishable by law. The value of your violation is " + data.fineAmount + " dirhams." +
      "And  " + data.dailyFines + " dirhams will be charge per day for late. Please initiate the payment of your violation in order to avoid the accumulation of fines." +
      "Your violation number is " + data.reference_number + ", Public Service Department - 072285688, Toll free number is 8008118 Location is https://goo.gl/maps/xqyvww6YbSB2, Petition Link: " + petitionLink + ", Payment Link: " + paymentLink + ""

    smsmessage = this.hexEncode(smsmessage);//this.toUnicode(smsmessage);
    //return this.http.get("http://"+sms_host_url+"/bulksms/bulksms?username="+sms_api_username+"&password="+sms_api_password+"&type="+sms_api_msgtype+"&dlr="+sms_api_dlr+"&destination="+modile_number+"&source="+sms_api_source+"&message="+smsmessage+"")

    let queryParams = new HttpParams();
    queryParams = queryParams.set("username", sms_api_username);
    queryParams = queryParams.set("password", sms_api_password);
    queryParams = queryParams.set("type", sms_api_msgtype);
    queryParams = queryParams.set("dlr", sms_api_dlr);
    queryParams = queryParams.set("destination", modile_number);
    queryParams = queryParams.set("source", sms_api_source);
    queryParams = queryParams.set("message", encodeURIComponent(smsmessage));

    return this.http.get("http://" + sms_host_url + "/bulksms/bulksms", { params: queryParams });
  }

  toUnicode(str): any {
    return str.split('').map((value, index, array) => {
      var temp = value.charCodeAt(0).toString(16).toUpperCase();
      if (temp.length > 2) {
        return '\\u' + temp;
      }
      return value;
    }).join('');
  }

  hexEncode(data: any): any {
    var hex, i;

    var result = "";
    for (i = 0; i < data.length; i++) {
      hex = data.charCodeAt(i).toString(16);
      result += ("000" + hex).slice(-4);
    }

    return result
  }

  logout() {
    let Obj = {
      "email": localStorage.getItem('currentUser'),
      "user_token": ""
    }
    this.auth.logout(Obj).subscribe((res) => {
      if (localStorage.getItem('remcredentials')) {
        const  remPassworddata = localStorage.getItem('remcredentials');
        localStorage.clear();
        localStorage.setItem('remcredentials', remPassworddata);
      }
      else
      {
        localStorage.clear();
      }
      this.connectivity.appIsOnline$.subscribe(async online => {

        console.log(online)

        if (online) {
          localStorage.setItem('isOnline', "true");
        }
        else {
          localStorage.setItem('isOnline', "false");
        }
      })

      this.routerServices.navigate(['/login']);
    }),
      (error) => {
        if (localStorage.getItem('remcredentials')) {
          const  remPassworddata = localStorage.getItem('remcredentials');
          localStorage.clear();
          localStorage.setItem('remcredentials', remPassworddata);
        }
        else
        {
          localStorage.clear();
        }
        this.connectivity.appIsOnline$.subscribe(async online => {

          console.log(online)

          if (online) {
            localStorage.setItem('isOnline', "true");
          }
          else {
            localStorage.setItem('isOnline', "false");
          }
        })

        this.routerServices.navigate(['/login']);
      };
    //this.logout();
  }

  /* Complaint System Code*/

  getAgencies(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/ListfineCategoryCode');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      //this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.vmsComplaintApiUrl + '/getAgencies', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  getComplaintTypes(body): Observable<any> {
    //return this.http.get(environment.apiUrl + '/ListfineCategoryCode');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
     // this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.vmsComplaintApiUrl + '/getComplaintTypes', body, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  getComplaintAreas(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/ListfineCategoryCode');
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      //this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.vmsComplaintApiUrl + '/getComplaintAreas', {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  CreateComplaint(body: any): Observable<any> {
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer('multipart')


      var url = environment.vmsComplaintApiUrl + '/insertComplaint/'

      let nativeHttpCall = this.httpobj.sendRequest(url, {
        method: "post",
        data: body,
        timeout: 60,
      })
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    })
  }


  ListComplaints(body: any): Observable<any> {
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      let nativeHttpCall = this.httpobj.post(environment.vmsComplaintApiUrl + '/getComplaintData/', body, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  // warningHours(): Observable<any>{    
  //   return this.http.get(environment.warningApiUrl + "getWarningHours");
  // }

  warningHours(): Observable<any> {
    //return this.http.get(environment.apiUrl + '/fineCode/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      // this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.get(environment.warningApiUrl + 'getWarningHours' , {}, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  viewWarningDeatails(data: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/voilations/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.warningApiUrl + '/getWarnings', data, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  getWarningList(data: any): Observable<any> {
    //return this.http.get(environment.apiUrl + '/voilations/' + id);
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.warningApiUrl + '/getWarnings', data, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.data
            ? JSON.parse(res.data.data)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
    });
  }

  updateWarningStatus(body: any): Observable<any>{
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.warningApiUrl + '/updateWarningStatus', body, {});
       from(nativeHttpCall).subscribe(
         (res: any) => {
           console.log("subscribedres",res)
           if (res.status == 401) {
             this.logout();
           }
           let response = res.data.data
             ? JSON.parse(res.data.data)
             : JSON.parse(res.data);
           Observer.next(response);
           Observer.complete();
         },
         (err) => {
           console.log("Suberror",err);
           if (err.status === 401) {
             this.logout();
           }
           Observer.error(err);
           Observer.complete();
         }
       );
     });
   
  }


  warningImage(body: any): Observable<any>{
    console.log("service body", body);
    return Observable.create((Observer) => {
      // this.httpobj.setDataSerializer('urlencoded');
      this.httpobj.setDataSerializer("multipart");
      // this.httpobj.setHeader('*', 'Content-Type', 'application/x-www-form-urlencoded');
      this.httpobj.setHeader('*', 'Content-Type', 'multipart/form-data');
      console.log("after dataserializer",body);
      
      // this.httpobj.setDataSerializer("json");
      // this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.warningDocumentPath, body, {});
       from(nativeHttpCall).subscribe(
         (res: any) => {
           console.log("subscribedres",res)
           if (res.status == 401) {
             this.logout();
           }
           let response = res.data.data
             ? JSON.parse(res.data.data)
             : JSON.parse(res.data);
           Observer.next(response);
           Observer.complete();
         },
         (err) => {
           console.log("Suberror",err);
           if (err.status === 401) {
             this.logout();
           }
           Observer.error(err);
           Observer.complete();
         }
       );
     });
   
  }

  warningVideo(body: any): Observable<any>{
    console.log("service body", body);
    return Observable.create((Observer) => {
      // this.httpobj.setDataSerializer('urlencoded');
      this.httpobj.setDataSerializer("multipart");
      // this.httpobj.setHeader('*', 'Content-Type', 'application/x-www-form-urlencoded');
      this.httpobj.setHeader('*', 'Content-Type', 'multipart/form-data');
      console.log("after dataserializer",body);
      
      // this.httpobj.setDataSerializer("json");
      // this.httpobj.setHeader(environment.authorizationURL, "Authorization", localStorage.getItem('hashToken'));
      let nativeHttpCall = this.httpobj.post(environment.warningVidoesPath, body, {});
       from(nativeHttpCall).subscribe(
         (res: any) => {
           console.log("subscribedres",res)
           if (res.status == 401) {
             this.logout();
           }
           let response = res.data.data
             ? JSON.parse(res.data.data)
             : JSON.parse(res.data);
           Observer.next(response);
           Observer.complete();
         },
         (err) => {
           console.log("Suberror",err);
           if (err.status === 401) {
             this.logout();
           }
           Observer.error(err);
           Observer.complete();
         }
       );
     });
   
  }

  /* ded Integration Invoking End Point */

  GetLicenceByParam(body: any): Observable<any> {
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
      //let nativeHttpCall = this.httpobj.post('https://rakdedlicdstg.ega.lan/QSInternalTest/QZone/IntegrationServices/RAKDED_LicenseDetailsByParam', body, {});
      let nativeHttpCall = this.httpobj.post(environment.vmsDedApiUrl +'getLicenseDetailsByParam', body, {});
      //let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/GetLicenseParamInfo/', body, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.ResponseContent
            ? JSON.parse(res.data.ResponseContent)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          this.toastService.showError(JSON.stringify(err),"Alert");
          alert(JSON.stringify(err))
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
     });
  }

  GetLicenseByLicenseNumber(body: any): Observable<any> {
    return Observable.create((Observer) => {
      this.httpobj.setDataSerializer("json");
     //let nativeHttpCall = this.httpobj.post('https://rakdedlicdstg.ega.lan/QSInternalTest/QZone/IntegrationServices/RAKDED_LicenseDetails', body, {});
     let nativeHttpCall = this.httpobj.post(environment.vmsDedApiUrl + 'getLicenseDetailsByNo', body, {});
     //let nativeHttpCall = this.httpobj.post(environment.apiUrl + '/GetLicenseByLicenseNumber/', body, {});
      from(nativeHttpCall).subscribe(
        (res: any) => {
          if (res.status == 401) {
            this.logout();
          }
          let response = res.data.ResponseContent
            ? JSON.parse(res.data.ResponseContent)
            : JSON.parse(res.data);
          Observer.next(response);
          Observer.complete();
        },
        (err) => {
          this.toastService.showError(JSON.stringify(err),"Alert");
          alert(JSON.stringify(err))
          if (err.status === 401) {
            this.logout();
          }
          Observer.error(err);
          Observer.complete();
        }
      );
     });
  }

  /* ded Integration Invoking End Point */

}
